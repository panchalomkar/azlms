<?php
$string['pluginname'] = 'Custom Dashboard';
$string['customdashboard'] = 'Custom Dashboard';
$string['customdashboard:addinstance'] = 'Add a new Custom Dashboard block';
$string['customdashboard:myaddinstance'] = 'Add a new Custom Dashboard block to the My Moodle page';
