<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_customdashboard';
$plugin->version   = 2026061800;
$plugin->requires  = 2024042200; // Moodle 4.4
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = '1.0';
