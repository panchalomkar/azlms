<?php
defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname' => '\core\event\course_module_viewed',
        'callback'  => '\local_customdashboard\observer::update_streak',
    ],
];
