<?php
namespace local_customdashboard;

defined('MOODLE_INTERNAL') || die();

/**
 * Pulls real Moodle data for the custom dashboard.
 * Adjust table/field names here if your Moodle version or installed
 * plugins (e.g. mod_attendance) differ from the assumptions below.
 */
class dashboard_data {

    /**
     * Assemble the full context array consumed by the dashboard mustache template.
     */
    public static function get_dashboard_data($userid) {
        $user = \core_user::get_user($userid);

        return [
            'greeting'         => self::get_greeting(),
            'username'         => $user->firstname,
            'streak'           => self::get_streak($userid),
            'continuelearning' => self::get_continue_learning($userid),
            'insights'         => self::get_insights($userid),
            'chart_html'       => self::get_weekly_chart_html($userid),
            'sessions'         => self::get_sessions_list($userid),
            'viewallurl'       => (new \moodle_url('/calendar/view.php'))->out(),
        ];
    }

    protected static function get_greeting() {
        $hour = (int) userdate(time(), '%H');
        if ($hour < 12) {
            return 'Good Morning';
        } else if ($hour < 17) {
            return 'Good Afternoon';
        }
        return 'Good Evening';
    }

    /**
     * Reads the streak table maintained by the observer.
     */
    public static function get_streak($userid) {
        global $DB;

        $record  = $DB->get_record('local_customdashboard_streak', ['userid' => $userid]);
        $current = $record ? (int) $record->currentstreak : 0;
        $capped  = min($current, 7);

        $monday = strtotime('monday this week');
        $days = [];
        for ($i = 0; $i < 7; $i++) {
            $daytime = strtotime("+{$i} days", $monday);
            $days[] = [
                'completed' => $i < $capped,
                'label'     => substr(strtoupper(userdate($daytime, '%a')), 0, 1),
            ];
        }

        return ['current' => $current, 'days' => $days];
    }

    /**
     * Finds the most recently accessed course that is not yet 100% complete.
     */
    public static function get_continue_learning($userid) {
        global $DB, $CFG;

        require_once($CFG->libdir . '/completionlib.php');

        $sql = "SELECT c.*
                  FROM {course} c
                  JOIN {user_lastaccess} ul ON ul.courseid = c.id
                 WHERE ul.userid = :userid AND c.id != :siteid
              ORDER BY ul.timeaccess DESC";
        $courses = $DB->get_records_sql($sql, ['userid' => $userid, 'siteid' => SITEID], 0, 15);

        foreach ($courses as $course) {
            $progress = \core_completion\progress::get_course_progress_percentage($course, $userid);
            if ($progress !== null && $progress < 100) {
                return [
                    'coursename' => format_string($course->fullname),
                    'lessoninfo' => self::get_next_incomplete_activity($course, $userid),
                    'progress'   => round($progress),
                    'courseurl'  => (new \moodle_url('/course/view.php', ['id' => $course->id]))->out(),
                ];
            }
        }

        return null; // No in-progress course found, template will hide the card.
    }

    protected static function get_next_incomplete_activity($course, $userid) {
        $completioninfo = new \completion_info($course);
        if (!$completioninfo->is_enabled()) {
            return '';
        }

        $activities = $completioninfo->get_activities();
        $total = count($activities);
        $index = 0;

        foreach ($activities as $cm) {
            $index++;
            $data = $completioninfo->get_data($cm, false, $userid);
            if ($data->completionstate == COMPLETION_INCOMPLETE) {
                return "Lesson {$index} of {$total} | " . format_string($cm->name);
            }
        }

        return '';
    }

    public static function get_insights($userid) {
        $courses   = enrol_get_users_courses($userid, true);
        $courseids = array_keys($courses);

        return [
            'courses'     => count($courses),
            'hours'       => self::get_hours_learned($userid, time() - WEEKSECS, time()),
            'attendance'  => self::get_attendance_percentage($userid, $courseids),
            'quizscore'   => self::get_quiz_average($userid, $courseids),
        ];
    }

    /**
     * Estimates active learning time from the standard log store.
     * Heuristic: gaps under 5 minutes between logged actions count as
     * continuous study time; isolated actions get a flat 60s credit.
     * This is the same general approach Moodle's own "Outline report" uses.
     */
    protected static function get_hours_learned($userid, $start, $end) {
        global $DB;

        if (!$DB->get_manager()->table_exists('logstore_standard_log')) {
            return 0;
        }

        $sql = "SELECT timecreated
                  FROM {logstore_standard_log}
                 WHERE userid = :userid AND timecreated BETWEEN :start AND :end
              ORDER BY timecreated ASC";
        $times = array_values($DB->get_fieldset_sql($sql, [
            'userid' => $userid, 'start' => $start, 'end' => $end,
        ]));

        $totalseconds = 0;
        $sessiongap = 300;       // 5 minutes.
        $singleactioncredit = 60; // Flat credit for an isolated action.

        for ($i = 1; $i < count($times); $i++) {
            $gap = $times[$i] - $times[$i - 1];
            $totalseconds += ($gap <= $sessiongap) ? $gap : $singleactioncredit;
        }

        return round($totalseconds / 3600, 1);
    }

    /**
     * Requires mod_attendance. Returns 0 if it's not installed yet.
     * Adjust the acronym list ('P', 'L') if your attendance statuses differ.
     */
    protected static function get_attendance_percentage($userid, $courseids) {
        global $DB;

        if (empty($courseids) || !$DB->get_manager()->table_exists('attendance_log')) {
            return 0;
        }

        list($insql, $params) = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED);
        $params['userid'] = $userid;

        $sql = "SELECT st.acronym, COUNT(al.id) AS cnt
                  FROM {attendance_log} al
                  JOIN {attendance_statuses} st ON st.id = al.statusid
                  JOIN {attendance_sessions} s ON s.id = al.sessionid
                  JOIN {attendance} a ON a.id = s.attendanceid
                 WHERE al.studentid = :userid AND a.course $insql
              GROUP BY st.acronym";
        $rows = $DB->get_records_sql($sql, $params);

        $present = 0;
        $total = 0;
        foreach ($rows as $row) {
            $total += $row->cnt;
            if (in_array($row->acronym, ['P', 'L'])) {
                $present += $row->cnt;
            }
        }

        return $total === 0 ? 0 : round(($present / $total) * 100);
    }

    protected static function get_quiz_average($userid, $courseids) {
        global $DB;

        if (empty($courseids)) {
            return 0;
        }

        list($insql, $params) = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED);
        $params['userid'] = $userid;

        $sql = "SELECT qg.grade, q.grade AS maxgrade
                  FROM {quiz_grades} qg
                  JOIN {quiz} q ON q.id = qg.quiz
                 WHERE qg.userid = :userid AND q.course $insql";
        $rows = $DB->get_records_sql($sql, $params);

        $percentages = [];
        foreach ($rows as $row) {
            if ($row->maxgrade > 0) {
                $percentages[] = ($row->grade / $row->maxgrade) * 100;
            }
        }

        return empty($percentages) ? 0 : round(array_sum($percentages) / count($percentages));
    }

    /**
     * Builds the weekly bar chart using Moodle's own Chart API (bundles Chart.js
     * already, so no extra JS library needs to be loaded).
     */
    public static function get_weekly_chart_html($userid) {
        global $OUTPUT;

        $labels = [];
        $values = [];
        $monday = strtotime('monday this week');

        for ($i = 0; $i < 7; $i++) {
            $daystart = strtotime("+{$i} days", $monday);
            $dayend   = $daystart + DAYSECS;
            $labels[] = userdate($daystart, '%a');
            $values[] = self::get_hours_learned($userid, $daystart, $dayend);
        }

        $series = new \core\chart_series('Hours', $values);
        $chart  = new \core\chart_bar();
        $chart->add_series($series);
        $chart->set_labels($labels);

        return $OUTPUT->render($chart);
    }

    /**
     * Lists enrolled courses with a Completed / On going / Not started status,
     * mirroring the "Sessions List" panel in the design.
     */
    public static function get_sessions_list($userid, $limit = 3) {
        $courses = enrol_get_users_courses($userid, true, '*', 'visible DESC, sortorder ASC');
        $sessions = [];

        foreach ($courses as $course) {
            if (count($sessions) >= $limit) {
                break;
            }

            $progress = \core_completion\progress::get_course_progress_percentage($course, $userid);

            if ($progress === null || $progress == 0) {
                $status = 'Not started';
                $statusclass = 'status-notstarted';
            } else if ($progress >= 100) {
                $status = 'Completed';
                $statusclass = 'status-completed';
            } else {
                $status = 'On going';
                $statusclass = 'status-ongoing';
            }

            $sessions[] = [
                'name'        => format_string($course->fullname),
                'duedate'     => $course->enddate ? userdate($course->enddate, '%b %d, %y') : 'No due date',
                'status'      => $status,
                'statusclass' => $statusclass,
                'url'         => (new \moodle_url('/course/view.php', ['id' => $course->id]))->out(),
            ];
        }

        return $sessions;
    }
}
