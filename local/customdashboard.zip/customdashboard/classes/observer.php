<?php
namespace local_customdashboard;

defined('MOODLE_INTERNAL') || die();

/**
 * Updates a user's learning streak whenever they view an activity.
 * Fires on every course_module_viewed event, but only writes to the
 * DB once per day per user (cheap to leave wired to a frequent event).
 */
class observer {

    public static function update_streak(\core\event\base $event) {
        global $DB;

        $userid = $event->userid;
        if (empty($userid) || isguestuser($userid)) {
            return;
        }

        $today     = strtotime('today midnight');
        $yesterday = strtotime('-1 day', $today);

        $record = $DB->get_record('local_customdashboard_streak', ['userid' => $userid]);

        if (!$record) {
            $record = new \stdClass();
            $record->userid        = $userid;
            $record->currentstreak = 1;
            $record->longeststreak = 1;
            $record->lastactivedate = $today;
            $record->timecreated   = time();
            $record->timemodified  = time();
            $DB->insert_record('local_customdashboard_streak', $record);
            return;
        }

        if ($record->lastactivedate == $today) {
            return; // Already counted today, nothing to do.
        }

        if ($record->lastactivedate == $yesterday) {
            $record->currentstreak += 1;
        } else {
            $record->currentstreak = 1; // Streak broken, gap of more than a day.
        }

        $record->longeststreak  = max($record->longeststreak, $record->currentstreak);
        $record->lastactivedate = $today;
        $record->timemodified   = time();

        $DB->update_record('local_customdashboard_streak', $record);
    }
}
