<?php
namespace local_courses;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

class external extends \external_api {

    // ── get_completion_popup ──────────────────────────────────────
    public static function get_completion_popup_parameters() {
        return new \external_function_parameters([
            'courseid' => new \external_value(PARAM_INT, 'Course ID'),
        ]);
    }

    public static function get_completion_popup(int $courseid): array {
        global $USER;
        self::validate_parameters(self::get_completion_popup_parameters(), ['courseid' => $courseid]);

        $helper = new course_helper();
        $courses = $helper->get_user_courses($USER->id, 'all');

        $course = array_filter($courses, fn($c) => $c['id'] === $courseid);
        $course = reset($course);

        return [
            'success'      => (bool)$course,
            'coursename'   => $course['fullname']   ?? '',
            'username'     => $course['username']   ?? '',
            'finalscore'   => $course['finalscore']  ?? 0,
            'quizaccuracy' => $course['quizaccuracy'] ?? 0,
        ];
    }

    public static function get_completion_popup_returns() {
        return new \external_single_structure([
            'success'      => new \external_value(PARAM_BOOL, 'Success'),
            'coursename'   => new \external_value(PARAM_TEXT, 'Course name'),
            'username'     => new \external_value(PARAM_TEXT, 'User name'),
            'finalscore'   => new \external_value(PARAM_INT,  'Final score'),
            'quizaccuracy' => new \external_value(PARAM_INT,  'Quiz accuracy'),
        ]);
    }

    // ── get_improvement_suggestions ──────────────────────────────
    public static function get_improvement_suggestions_parameters() {
        return new \external_function_parameters([
            'courseid' => new \external_value(PARAM_INT, 'Course ID'),
        ]);
    }

    public static function get_improvement_suggestions(int $courseid): array {
        global $USER;
        self::validate_parameters(self::get_improvement_suggestions_parameters(), ['courseid' => $courseid]);

        $helper      = new course_helper();
        $suggestions = $helper->get_improvement_suggestions($USER->id, $courseid);

        return ['suggestions' => json_encode($suggestions)];
    }

    public static function get_improvement_suggestions_returns() {
        return new \external_single_structure([
            'suggestions' => new \external_value(PARAM_RAW, 'JSON suggestions'),
        ]);
    }
}
